=== AI Football Predictor ===
Contributors: aifootpredictor
Tags: football, soccer, widget, predictions, live scores
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Football match probabilities on your site: free widgets, and match previews written for your site with AI Football Predictor Pro.

== Description ==

Show the win, draw and loss probabilities of the next football matches on your WordPress site, updated automatically: Premier League, Ligue 1, LaLiga, Serie A, Bundesliga, Champions League and many more competitions, men's and women's football.

**Free**

* A block, a sidebar widget and a shortcode: `[aifp competitions="E0,CL" n="6"]`
* Next matches, live matches, projected league table, a club's next match, latest previews
* English or French, dark or light theme

**AI Football Predictor Pro**

* Up to 10 match previews a day, written for your site only (no other site gets the same text), imported every hour as drafts or published posts
* The result is added to each article after the match
* Widgets in your colours with your logo, ad-free

Probabilities are statistical estimates for information, not betting advice.

== External services ==

This plugin displays data from AI Football Predictor (https://aifootpredictor.com/).

* The widgets load the script https://aifootpredictor.com/embed.js, which shows an iframe from https://aifootpredictor.com/w/. The visitor's browser sends the page's host name, to count the widget's use. Terms: https://aifootpredictor.com/terms/ Privacy: https://aifootpredictor.com/privacy/
* With a Pro feed address, your site calls https://afp-blog-production.up.railway.app/api/pro/feed every hour to fetch the articles written for you. Only the feed token is sent.

== Installation ==

1. Upload the plugin and activate it.
2. Add the "AI Football Predictor" block, widget or the `[aifp]` shortcode.
3. Pro: paste your feed address in Settings > AI Football Predictor.

== Changelog ==

= 1.0.0 =
* First version: free widgets (block, widget, shortcode) and Pro article import.

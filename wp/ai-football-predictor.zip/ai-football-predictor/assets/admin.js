/* AI Football Predictor - shortcode builder and live preview */
( function () {
	var root = document.getElementById( 'aifp-builder' );
	if ( ! root ) return;
	var $ = function ( s ) { return root.querySelector( s ); };
	var f = { type: $( '#aifp-b-type' ), comps: $( '#aifp-b-comps' ), team: $( '#aifp-b-team' ), n: $( '#aifp-b-n' ), lang: $( '#aifp-b-lang' ), theme: $( '#aifp-b-theme' ) };
	var out = $( '#aifp-b-code' ), prev = $( '#aifp-b-prev' ), t;
	function code() {
		var a = [ '[aifp' ];
		if ( f.type.value !== 'matches' ) a.push( 'type="' + f.type.value + '"' );
		var c = f.comps.value.replace( /[^A-Za-z0-9_,]/g, '' );
		if ( c ) a.push( 'competitions="' + c + '"' );
		var tm = f.team.value.replace( /["\]\[]/g, '' ).trim();
		if ( tm ) a.push( 'team="' + tm + '"' );
		if ( f.n.value && f.n.value !== '6' ) a.push( 'n="' + parseInt( f.n.value, 10 ) + '"' );
		if ( f.lang.value !== root.dataset.lang ) a.push( 'lang="' + f.lang.value + '"' );
		if ( f.theme.value === 'light' ) a.push( 'theme="light"' );
		return a.join( ' ' ) + ']';
	}
	function render() {
		out.textContent = code();
		root.querySelectorAll( '.aifp-chips button' ).forEach( function ( b ) {
			b.classList.toggle( 'on', ( ',' + f.comps.value + ',' ).indexOf( ',' + b.dataset.c + ',' ) >= 0 );
		} );
		clearTimeout( t );
		t = setTimeout( function () {
			var d = document.createElement( 'div' );
			d.className = 'afp-widget';
			d.dataset.lang = f.lang.value;
			if ( f.type.value !== 'matches' ) d.dataset.type = f.type.value;
			if ( f.comps.value ) d.dataset.lg = f.comps.value.replace( /[^A-Za-z0-9_,]/g, '' );
			if ( f.team.value ) d.dataset.team = f.team.value;
			d.dataset.n = f.n.value || '6';
			if ( f.theme.value === 'light' ) d.dataset.theme = 'light';
			if ( root.dataset.p ) d.dataset.p = root.dataset.p;
			prev.innerHTML = '';
			prev.appendChild( d );
			var s = document.createElement( 'script' );
			s.src = 'https://aifootpredictor.com/embed.js?v=' + Date.now();
			s.async = true;
			prev.appendChild( s );
		}, 450 );
	}
	Object.keys( f ).forEach( function ( k ) { f[ k ].addEventListener( 'input', render ); f[ k ].addEventListener( 'change', render ); } );
	root.querySelectorAll( '.aifp-chips button' ).forEach( function ( b ) {
		b.addEventListener( 'click', function ( e ) {
			e.preventDefault();
			var l = f.comps.value ? f.comps.value.split( ',' ).filter( Boolean ) : [], i = l.indexOf( b.dataset.c );
			if ( i >= 0 ) l.splice( i, 1 ); else l.push( b.dataset.c );
			f.comps.value = l.join( ',' );
			render();
		} );
	} );
	$( '#aifp-b-copy' ).addEventListener( 'click', function ( e ) {
		e.preventDefault();
		var b = this, done = function () { b.textContent = root.dataset.copied; setTimeout( function () { b.textContent = root.dataset.copy; }, 1600 ); };
		if ( navigator.clipboard ) navigator.clipboard.writeText( out.textContent ).then( done, done ); else done();
	} );
	render();
} )();

/* AI Football Predictor - shortcode builder and live preview */
( function () {
	var root = document.getElementById( 'aifp-builder' );
	if ( ! root ) return;
	var $ = function ( s ) { return root.querySelector( s ); };
	var f = { type: $( '#aifp-b-type' ), comps: $( '#aifp-b-comps' ), team: $( '#aifp-b-team' ), n: $( '#aifp-b-n' ), lang: $( '#aifp-b-lang' ), theme: $( '#aifp-b-theme' ) };
	var out = $( '#aifp-b-code' ), prev = $( '#aifp-b-prev' ), t;
	function code() {
		var a = [ '[aifp' ];
		if ( f.type.value !== 'matches' ) a.push( 'type="' + f.type.value + '"' );
		var c = f.comps.value.replace( /[^A-Za-z0-9_,]/g, '' );
		if ( c ) a.push( 'competitions="' + c + '"' );
		var tm = f.team.value.replace( /["\]\[]/g, '' ).trim();
		if ( tm ) a.push( 'team="' + tm + '"' );
		if ( f.n.value && f.n.value !== '6' ) a.push( 'n="' + parseInt( f.n.value, 10 ) + '"' );
		if ( f.lang.value !== root.dataset.lang ) a.push( 'lang="' + f.lang.value + '"' );
		if ( f.theme.value === 'light' ) a.push( 'theme="light"' );
		return a.join( ' ' ) + ']';
	}
	function render() {
		out.textContent = code();
		root.querySelectorAll( '.aifp-chips button' ).forEach( function ( b ) {
			b.classList.toggle( 'on', ( ',' + f.comps.value + ',' ).indexOf( ',' + b.dataset.c + ',' ) >= 0 );
		} );
		clearTimeout( t );
		t = setTimeout( function () {
			var d = document.createElement( 'div' );
			d.className = 'afp-widget';
			d.dataset.lang = f.lang.value;
			if ( f.type.value !== 'matches' ) d.dataset.type = f.type.value;
			if ( f.comps.value ) d.dataset.lg = f.comps.value.replace( /[^A-Za-z0-9_,]/g, '' );
			if ( f.team.value ) d.dataset.team = f.team.value;
			d.dataset.n = f.n.value || '6';
			if ( f.theme.value === 'light' ) d.dataset.theme = 'light';
			if ( root.dataset.p ) d.dataset.p = root.dataset.p;
			prev.innerHTML = '';
			prev.appendChild( d );
			var s = document.createElement( 'script' );
			s.src = 'https://aifootpredictor.com/embed.js?v=' + Date.now();
			s.async = true;
			prev.appendChild( s );
		}, 450 );
	}
	Object.keys( f ).forEach( function ( k ) { f[ k ].addEventListener( 'input', render ); f[ k ].addEventListener( 'change', render ); } );
	root.querySelectorAll( '.aifp-chips button' ).forEach( function ( b ) {
		b.addEventListener( 'click', function ( e ) {
			e.preventDefault();
			var l = f.comps.value ? f.comps.value.split( ',' ).filter( Boolean ) : [], i = l.indexOf( b.dataset.c );
			if ( i >= 0 ) l.splice( i, 1 ); else l.push( b.dataset.c );
			f.comps.value = l.join( ',' );
			render();
		} );
	} );
	$( '#aifp-b-copy' ).addEventListener( 'click', function ( e ) {
		e.preventDefault();
		var b = this, done = function () { b.textContent = root.dataset.copied; setTimeout( function () { b.textContent = root.dataset.copy; }, 1600 ); };
		if ( navigator.clipboard ) navigator.clipboard.writeText( out.textContent ).then( done, done ); else done();
	} );
	render();
} )();

/* Pro widget style: themes, colours, logo from the Media Library, live preview */
( function () {
	var card = document.getElementById( 'aifp-style' );
	if ( ! card ) return;
	var q = function ( s ) { return card.querySelector( s ); };
	var bg = q( '#aifp-c-bg' ), tx = q( '#aifp-c-txt' ), ac = q( '#aifp-c-acc' ), mock = q( '#aifp-mock' ), img = q( '#aifp-logo-img' ), lid = q( '#aifp-logo-id' ), del = q( '#aifp-logo-del' );
	var fr = !! mock.dataset.fr;
	var rows = fr ? [ [ 'PSG', 'Lyon', 58, 23, 19 ], [ 'Marseille', 'Lens', 44, 28, 28 ], [ 'Monaco', 'Nice', 47, 26, 27 ] ] : [ [ 'Arsenal', 'Chelsea', 52, 25, 23 ], [ 'Liverpool', 'Spurs', 61, 21, 18 ], [ 'Newcastle', 'Villa', 45, 27, 28 ] ];
	function esc( s ) { return String( s ).replace( /[&<>"]/g, function ( c ) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ c ]; } ); }
	function draw() {
		var b = bg.value, t = tx.value, a = ac.value, im = img.querySelector( 'img' );
		[ bg, tx, ac ].forEach( function ( i ) { var s = i.parentNode.querySelector( 'b' ); if ( s ) s.textContent = i.value; } );
		var h = '<div class="m" style="background:' + b + ';color:' + t + '"><div class="mh">' + ( im ? '<img src="' + esc( im.src ) + '" alt="">' : '' ) + '<b>' + ( fr ? 'Probabilités foot' : 'Football probabilities' ) + '</b></div>';
		rows.forEach( function ( r ) {
			h += '<div class="mr" style="border-color:' + t + '22"><div class="mt"><span>' + r[ 0 ] + ' - ' + r[ 1 ] + '</span><b style="color:' + a + '">' + r[ 2 ] + ' %</b></div><div class="mb" style="background:' + t + '1f"><i style="width:' + r[ 2 ] + '%;background:' + a + '"></i><i style="width:' + r[ 3 ] + '%;background:' + t + '55"></i></div><div class="mp" style="color:' + t + 'aa"><span>1 ' + r[ 2 ] + '%</span><span>' + ( fr ? 'N ' : 'X ' ) + r[ 3 ] + '%</span><span>2 ' + r[ 4 ] + '%</span></div></div>';
		} );
		mock.innerHTML = h + '</div>';
	}
	[ bg, tx, ac ].forEach( function ( i ) { i.addEventListener( 'input', draw ); } );
	card.querySelectorAll( '.aifp-th button' ).forEach( function ( btn ) {
		btn.addEventListener( 'click', function () { var t = btn.dataset.t.split( ',' ); bg.value = t[ 0 ]; tx.value = t[ 1 ]; ac.value = t[ 2 ]; draw(); } );
	} );
	var frame;
	q( '#aifp-logo-pick' ).addEventListener( 'click', function ( e ) {
		e.preventDefault();
		if ( ! window.wp || ! wp.media ) return;
		if ( ! frame ) {
			frame = wp.media( { title: this.dataset.title, button: { text: this.dataset.button }, library: { type: [ 'image/png', 'image/jpeg', 'image/webp' ] }, multiple: false } );
			frame.on( 'select', function () {
				var at = frame.state().get( 'selection' ).first().toJSON(), u = at.sizes && at.sizes.thumbnail ? at.sizes.thumbnail.url : at.url;
				lid.value = at.id;
				img.innerHTML = '<img src="' + esc( u ) + '" alt="">';
				del.hidden = false;
				draw();
			} );
		}
		frame.open();
	} );
	del.addEventListener( 'click', function ( e ) { e.preventDefault(); lid.value = '0'; img.innerHTML = ''; del.hidden = true; draw(); } );
	draw();
} )();

<?php
/**
 * Plugin Name:       AI Football Predictor
 * Plugin URI:        https://aifootpredictor.com/widget/
 * Description:       Football match probabilities on your site: free widgets (shortcode, block, sidebar widget) and, for AI Football Predictor Pro, match previews written for your site and imported automatically.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            AI Football Predictor
 * Author URI:        https://aifootpredictor.com/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ai-football-predictor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AIFP_VERSION', '1.0.0' );
define( 'AIFP_SITE', 'https://aifootpredictor.com/' );
define( 'AIFP_FEED_HOST', 'afp-blog-production.up.railway.app' );

/** French or English, from the site language. */
function aifp_fr() {
	return 0 === strpos( determine_locale(), 'fr' );
}
function aifp_t( $fr, $en ) {
	return aifp_fr() ? $fr : $en;
}

/* -------------------------------------------------------------------------
 * 1. Free widgets: [aifp] shortcode, block and sidebar widget
 * ---------------------------------------------------------------------- */

/**
 * Widget HTML (the official embed code, rendered server side).
 *
 * @param array $a type (matches|live|match|team|table|articles), lang, competitions, team, match, n, theme.
 */
function aifp_widget_html( $a ) {
	$a = shortcode_atts(
		array(
			'type'         => 'matches',
			'lang'         => aifp_fr() ? 'fr' : 'en',
			'competitions' => '',
			'team'         => '',
			'match'        => '',
			'n'            => '6',
			'theme'        => 'dark',
		),
		$a,
		'aifp'
	);
	$fr    = 'fr' === $a['lang'];
	$type  = in_array( $a['type'], array( 'matches', 'live', 'match', 'team', 'table', 'articles', 'badge' ), true ) ? $a['type'] : 'matches';
	$attrs = ' data-lang="' . esc_attr( $fr ? 'fr' : 'en' ) . '"';
	if ( 'matches' !== $type ) {
		$attrs .= ' data-type="' . esc_attr( $type ) . '"';
	}
	if ( '' !== $a['competitions'] ) {
		$attrs .= ' data-lg="' . esc_attr( preg_replace( '/[^A-Za-z0-9_,]/', '', $a['competitions'] ) ) . '"';
	}
	if ( '' !== $a['team'] ) {
		$attrs .= ' data-team="' . esc_attr( $a['team'] ) . '"';
	}
	if ( '' !== $a['match'] ) {
		$attrs .= ' data-match="' . esc_attr( preg_replace( '/[^0-9]/', '', $a['match'] ) ) . '"';
	}
	$attrs .= ' data-n="' . esc_attr( max( 1, min( 20, absint( $a['n'] ) ) ) ) . '"';
	if ( 'light' === $a['theme'] ) {
		$attrs .= ' data-theme="light"';
	}
	$style = trim( (string) get_option( 'aifp_style_key', '' ) );
	if ( '' !== $style ) {
		$attrs .= ' data-p="' . esc_attr( preg_replace( '/[^A-Za-z0-9_-]/', '', $style ) ) . '"';
	}
	wp_enqueue_script( 'aifp-embed', AIFP_SITE . 'embed.js', array(), AIFP_VERSION, array( 'in_footer' => true, 'strategy' => 'async' ) );
	$label = $fr ? 'Probabilités foot par AI Football Predictor' : 'Football probabilities by AI Football Predictor';
	return '<div class="afp-widget"' . $attrs . '><a href="' . esc_url( AIFP_SITE . ( $fr ? 'fr/' : '' ) ) . '">' . esc_html( $label ) . '</a></div>';
}
add_shortcode( 'aifp', 'aifp_widget_html' );

/** Block (no build step: plain JS editor script, server-side render). */
function aifp_register_block() {
	wp_register_script(
		'aifp-block-editor',
		plugins_url( 'blocks/editor.js', __FILE__ ),
		array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-server-side-render' ),
		AIFP_VERSION,
		true
	);
	wp_localize_script( 'aifp-block-editor', 'AIFP_I18N', array( 'fr' => aifp_fr() ) );
	register_block_type(
		'aifp/widget',
		array(
			'editor_script'   => 'aifp-block-editor',
			'render_callback' => 'aifp_widget_html',
			'attributes'      => array(
				'type'         => array( 'type' => 'string', 'default' => 'matches' ),
				'lang'         => array( 'type' => 'string', 'default' => aifp_fr() ? 'fr' : 'en' ),
				'competitions' => array( 'type' => 'string', 'default' => '' ),
				'team'         => array( 'type' => 'string', 'default' => '' ),
				'n'            => array( 'type' => 'string', 'default' => '6' ),
				'theme'        => array( 'type' => 'string', 'default' => 'dark' ),
			),
		)
	);
}
add_action( 'init', 'aifp_register_block' );

/** Sidebar widget. */
class AIFP_Sidebar_Widget extends WP_Widget {
	public function __construct() {
		parent::__construct( 'aifp_widget', 'AI Football Predictor', array( 'description' => aifp_t( 'Les probabilités des prochains matchs de foot.', 'Probabilities of the next football matches.' ) ) );
	}
	public function widget( $args, $instance ) {
		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo aifp_widget_html( $instance ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	public function form( $instance ) {
		$f = array(
			'title'        => aifp_t( 'Titre', 'Title' ),
			'competitions' => aifp_t( 'Compétitions (codes, ex. F1,CL)', 'Competitions (codes, e.g. E0,CL)' ),
			'team'         => aifp_t( 'Club (facultatif)', 'Club (optional)' ),
			'n'            => aifp_t( 'Nombre de matchs', 'Number of matches' ),
		);
		foreach ( $f as $k => $label ) {
			printf( '<p><label for="%1$s">%2$s</label><input class="widefat" id="%1$s" name="%3$s" value="%4$s"></p>', esc_attr( $this->get_field_id( $k ) ), esc_html( $label ), esc_attr( $this->get_field_name( $k ) ), esc_attr( isset( $instance[ $k ] ) ? $instance[ $k ] : ( 'n' === $k ? '6' : '' ) ) );
		}
		$th = isset( $instance['theme'] ) ? $instance['theme'] : 'dark';
		printf( '<p><label for="%1$s">%2$s</label> <select id="%1$s" name="%3$s"><option value="dark"%4$s>%5$s</option><option value="light"%6$s>%7$s</option></select></p>', esc_attr( $this->get_field_id( 'theme' ) ), esc_html( aifp_t( 'Thème', 'Theme' ) ), esc_attr( $this->get_field_name( 'theme' ) ), selected( $th, 'dark', false ), esc_html( aifp_t( 'Sombre', 'Dark' ) ), selected( $th, 'light', false ), esc_html( aifp_t( 'Clair', 'Light' ) ) );
	}
	public function update( $new, $old ) {
		return array(
			'title'        => sanitize_text_field( $new['title'] ),
			'competitions' => sanitize_text_field( $new['competitions'] ),
			'team'         => sanitize_text_field( $new['team'] ),
			'n'            => (string) max( 1, min( 20, absint( $new['n'] ) ) ),
			'theme'        => 'light' === $new['theme'] ? 'light' : 'dark',
		);
	}
}
add_action(
	'widgets_init',
	function () {
		register_widget( 'AIFP_Sidebar_Widget' );
	}
);

/* -------------------------------------------------------------------------
 * 2. Pro: match previews written for this site, imported every hour
 * ---------------------------------------------------------------------- */

register_activation_hook(
	__FILE__,
	function () {
		if ( ! wp_next_scheduled( 'aifp_import' ) ) {
			wp_schedule_event( time() + 300, 'hourly', 'aifp_import' );
		}
	}
);
register_deactivation_hook(
	__FILE__,
	function () {
		wp_clear_scheduled_hook( 'aifp_import' );
	}
);
add_action( 'aifp_import', 'aifp_import' );

/** Only accepts the official feed address. */
function aifp_feed_url() {
	$u = trim( (string) get_option( 'aifp_feed_url', '' ) );
	if ( '' === $u ) {
		return '';
	}
	$p = wp_parse_url( $u );
	if ( empty( $p['host'] ) || AIFP_FEED_HOST !== $p['host'] || empty( $p['query'] ) ) {
		return '';
	}
	parse_str( $p['query'], $q );
	if ( empty( $q['t'] ) ) {
		return '';
	}
	return 'https://' . AIFP_FEED_HOST . '/api/pro/feed?t=' . rawurlencode( preg_replace( '/[^a-f0-9]/', '', $q['t'] ) );
}

/**
 * Imports the new articles of the Pro feed, and adds the result to the ones already imported
 * (only if the post was not edited by hand since).
 *
 * @return array{ok:bool,msg:string,new:int,upd:int}
 */
function aifp_import() {
	$url = aifp_feed_url();
	if ( '' === $url ) {
		return aifp_log( false, aifp_t( 'Aucune adresse de flux valide.', 'No valid feed address.' ) );
	}
	$r = wp_remote_get( $url, array( 'timeout' => 20 ) );
	if ( is_wp_error( $r ) ) {
		return aifp_log( false, $r->get_error_message() );
	}
	$code = wp_remote_retrieve_response_code( $r );
	$j    = json_decode( wp_remote_retrieve_body( $r ), true );
	if ( 403 === $code ) {
		return aifp_log( false, aifp_t( 'Votre abonnement AI Football Predictor Pro n’est pas actif.', 'Your AI Football Predictor Pro subscription is not active.' ) );
	}
	if ( 200 !== $code || ! is_array( $j ) || ! isset( $j['articles'] ) ) {
		return aifp_log( false, aifp_t( 'Flux introuvable. Vérifiez l’adresse dans votre Espace Pro.', 'Feed not found. Check the address in your Pro space.' ) . ' (HTTP ' . (int) $code . ')' );
	}
	$status = 'publish' === get_option( 'aifp_status', 'draft' ) ? 'publish' : 'draft';
	$cat    = absint( get_option( 'aifp_category', 0 ) );
	$author = absint( get_option( 'aifp_author', 0 ) );
	$thumb  = absint( get_option( 'aifp_thumbnail', 0 ) );
	$new    = 0;
	$upd    = 0;
	foreach ( array_reverse( $j['articles'] ) as $a ) {
		if ( empty( $a['id'] ) || empty( $a['title'] ) || empty( $a['html'] ) ) {
			continue;
		}
		$html  = wp_kses_post( $a['html'] );
		$found = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => 'any',
				'meta_key'       => '_aifp_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => (string) $a['id'], // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);
		if ( $found ) {
			$pid = $found[0];
			$cur = get_post_field( 'post_content', $pid );
			if ( $cur !== $html && md5( $cur ) === get_post_meta( $pid, '_aifp_hash', true ) ) {
				wp_update_post( array( 'ID' => $pid, 'post_content' => $html ) );
				update_post_meta( $pid, '_aifp_hash', md5( get_post_field( 'post_content', $pid ) ) );
				++$upd;
			}
			continue;
		}
		$post = array(
			'post_title'   => sanitize_text_field( $a['title'] ),
			'post_content' => $html,
			'post_excerpt' => isset( $a['lede'] ) ? sanitize_text_field( $a['lede'] ) : '',
			'post_status'  => $status,
			'post_type'    => 'post',
		);
		if ( $cat ) {
			$post['post_category'] = array( $cat );
		}
		if ( $author ) {
			$post['post_author'] = $author;
		}
		$pid = wp_insert_post( $post, true );
		if ( is_wp_error( $pid ) ) {
			continue;
		}
		if ( ! empty( $a['tags'] ) && is_array( $a['tags'] ) ) {
			wp_set_post_tags( $pid, array_map( 'sanitize_text_field', $a['tags'] ) );
		}
		if ( $thumb ) {
			set_post_thumbnail( $pid, $thumb );
		}
		update_post_meta( $pid, '_aifp_id', (string) $a['id'] );
		update_post_meta( $pid, '_aifp_hash', md5( get_post_field( 'post_content', $pid ) ) );
		++$new;
	}
	return aifp_log( true, sprintf( aifp_t( '%1$d nouvel(s) article(s), %2$d mis à jour avec le résultat.', '%1$d new article(s), %2$d updated with the result.' ), $new, $upd ), $new, $upd );
}
function aifp_log( $ok, $msg, $new = 0, $upd = 0 ) {
	$r = array(
		'ok'  => $ok,
		'msg' => $msg,
		'new' => $new,
		'upd' => $upd,
		'at'  => time(),
	);
	update_option( 'aifp_last_import', $r, false );
	return $r;
}

/* -------------------------------------------------------------------------
 * 3. Settings page (Settings > AI Football Predictor)
 * ---------------------------------------------------------------------- */

add_action(
	'admin_menu',
	function () {
		add_options_page( 'AI Football Predictor', 'AI Football Predictor', 'manage_options', 'aifp', 'aifp_settings_page' );
	}
);
add_action(
	'admin_init',
	function () {
		register_setting( 'aifp', 'aifp_feed_url', array( 'type' => 'string', 'sanitize_callback' => 'esc_url_raw' ) );
		register_setting( 'aifp', 'aifp_status', array( 'type' => 'string', 'sanitize_callback' => function ( $v ) { return 'publish' === $v ? 'publish' : 'draft'; } ) );
		register_setting( 'aifp', 'aifp_category', array( 'type' => 'integer', 'sanitize_callback' => 'absint' ) );
		register_setting( 'aifp', 'aifp_author', array( 'type' => 'integer', 'sanitize_callback' => 'absint' ) );
		register_setting( 'aifp', 'aifp_thumbnail', array( 'type' => 'integer', 'sanitize_callback' => 'absint' ) );
		register_setting( 'aifp', 'aifp_style_key', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ) );
	}
);
add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	function ( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=aifp' ) ) . '">' . esc_html( aifp_t( 'Réglages', 'Settings' ) ) . '</a>' );
		return $links;
	}
);
add_action(
	'admin_post_aifp_import_now',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'forbidden' );
		}
		check_admin_referer( 'aifp_import_now' );
		aifp_import();
		wp_safe_redirect( admin_url( 'options-general.php?page=aifp&imported=1' ) );
		exit;
	}
);

function aifp_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$fr   = aifp_fr();
	$last = get_option( 'aifp_last_import' );
	$pro  = AIFP_SITE . ( $fr ? 'fr/' : '' ) . 'pro/?src=wp';
	?>
	<div class="wrap">
		<h1>AI Football Predictor</h1>

		<h2><?php echo esc_html( aifp_t( '1. Widgets gratuits', '1. Free widgets' ) ); ?></h2>
		<p><?php echo esc_html( aifp_t( 'Ajoutez le bloc « AI Football Predictor » dans l’éditeur, le widget du même nom dans une barre latérale, ou ce shortcode :', 'Add the “AI Football Predictor” block in the editor, the widget of the same name in a sidebar, or this shortcode:' ) ); ?></p>
		<p><code>[aifp competitions="F1,CL" n="6"]</code> &nbsp; <code>[aifp type="live"]</code> &nbsp; <code>[aifp type="table" competitions="E0"]</code> &nbsp; <code>[aifp team="Lyon"]</code></p>
		<p class="description"><?php echo esc_html( aifp_t( 'Codes des compétitions : E0 Premier League, F1 Ligue 1, SP1 LaLiga, I1 Serie A, D1 Bundesliga, CL Ligue des champions, et d’autres sur aifootpredictor.com/fr/widget/. Options : type (matches, live, table, team, articles), lang (fr, en), n (nombre de matchs), theme (dark, light).', 'Competition codes: E0 Premier League, F1 Ligue 1, SP1 LaLiga, I1 Serie A, D1 Bundesliga, CL Champions League, and more on aifootpredictor.com/widget/. Options: type (matches, live, table, team, articles), lang (fr, en), n (number of matches), theme (dark, light).' ) ); ?></p>

		<form method="post" action="options.php">
			<?php settings_fields( 'aifp' ); ?>
			<h2><?php echo esc_html( aifp_t( '2. AI Football Predictor Pro', '2. AI Football Predictor Pro' ) ); ?></h2>
			<p><?php echo esc_html( aifp_t( 'Avec Pro, des avant-matchs écrits pour votre site uniquement arrivent ici chaque heure, avec le résultat ajouté après le match. Vos widgets prennent vos couleurs et votre logo, sans pub.', 'With Pro, match previews written for your site only arrive here every hour, with the result added after the match. Your widgets take your colours and logo, ad-free.' ) ); ?>
				<a href="<?php echo esc_url( $pro ); ?>" target="_blank" rel="noopener"><?php echo esc_html( aifp_t( 'Découvrir Pro', 'Discover Pro' ) ); ?></a></p>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="aifp_feed_url"><?php echo esc_html( aifp_t( 'Adresse de votre flux', 'Your feed address' ) ); ?></label></th>
					<td><input type="url" class="large-text" id="aifp_feed_url" name="aifp_feed_url" value="<?php echo esc_attr( get_option( 'aifp_feed_url', '' ) ); ?>" placeholder="https://<?php echo esc_attr( AIFP_FEED_HOST ); ?>/api/pro/feed?t=...">
					<p class="description"><?php echo esc_html( aifp_t( 'Dans votre Espace Pro sur aifootpredictor.com, bouton « JSON » sous « Articles pour votre site ».', 'In your Pro space on aifootpredictor.com, “JSON” button under “Articles for your site”.' ) ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php echo esc_html( aifp_t( 'Publication', 'Publishing' ) ); ?></th>
					<td><select name="aifp_status"><option value="draft" <?php selected( get_option( 'aifp_status', 'draft' ), 'draft' ); ?>><?php echo esc_html( aifp_t( 'En brouillon (je relis avant)', 'As drafts (I review first)' ) ); ?></option><option value="publish" <?php selected( get_option( 'aifp_status', 'draft' ), 'publish' ); ?>><?php echo esc_html( aifp_t( 'Publier directement', 'Publish right away' ) ); ?></option></select></td>
				</tr>
				<tr>
					<th scope="row"><?php echo esc_html( aifp_t( 'Catégorie', 'Category' ) ); ?></th>
					<td><?php wp_dropdown_categories( array( 'name' => 'aifp_category', 'selected' => absint( get_option( 'aifp_category', 0 ) ), 'show_option_none' => aifp_t( '(catégorie par défaut)', '(default category)' ), 'option_none_value' => 0, 'hide_empty' => false ) ); ?></td>
				</tr>
				<tr>
					<th scope="row"><?php echo esc_html( aifp_t( 'Auteur', 'Author' ) ); ?></th>
					<td><?php wp_dropdown_users( array( 'name' => 'aifp_author', 'selected' => absint( get_option( 'aifp_author', 0 ) ), 'show_option_none' => aifp_t( '(auteur par défaut)', '(default author)' ), 'option_none_value' => 0, 'capability' => array( 'edit_posts' ) ) ); ?></td>
				</tr>
				<tr>
					<th scope="row"><label for="aifp_thumbnail"><?php echo esc_html( aifp_t( 'Image à la une', 'Featured image' ) ); ?></label></th>
					<td><input type="number" min="0" id="aifp_thumbnail" name="aifp_thumbnail" value="<?php echo esc_attr( (string) absint( get_option( 'aifp_thumbnail', 0 ) ) ); ?>" class="small-text">
					<p class="description"><?php echo esc_html( aifp_t( 'Facultatif : numéro (ID) d’une image de votre médiathèque, mise sur chaque article.', 'Optional: ID of an image from your media library, set on every article.' ) ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><label for="aifp_style_key"><?php echo esc_html( aifp_t( 'Clé de style Pro des widgets', 'Pro widget style key' ) ); ?></label></th>
					<td><input type="text" class="regular-text" id="aifp_style_key" name="aifp_style_key" value="<?php echo esc_attr( get_option( 'aifp_style_key', '' ) ); ?>">
					<p class="description"><?php echo esc_html( aifp_t( 'Facultatif : la valeur data-p du code de votre widget Pro, pour vos couleurs et votre logo.', 'Optional: the data-p value in your Pro widget code, for your colours and logo.' ) ); ?></p></td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="aifp_import_now">
			<?php wp_nonce_field( 'aifp_import_now' ); ?>
			<?php submit_button( aifp_t( 'Importer maintenant', 'Import now' ), 'secondary', 'submit', false ); ?>
			<?php if ( is_array( $last ) ) : ?>
				<p><?php echo esc_html( ( $last['ok'] ? '✅ ' : '⚠️ ' ) . wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $last['at'] ) . ' : ' . $last['msg'] ); ?></p>
			<?php endif; ?>
		</form>

		<p class="description"><?php echo esc_html( aifp_t( 'Besoin de plus (plusieurs sites, plus d’articles) ?', 'Need more (several sites, more articles)?' ) ); ?> <a href="<?php echo esc_url( AIFP_SITE . ( $fr ? 'fr/' : '' ) . 'support/?src=wp' ); ?>" target="_blank" rel="noopener"><?php echo esc_html( aifp_t( 'Contactez-nous', 'Contact us' ) ); ?></a></p>
	</div>
	<?php
}

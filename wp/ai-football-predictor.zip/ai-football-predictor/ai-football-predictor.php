<?php
/**
 * Plugin Name:       AI Football Predictor
 * Plugin URI:        https://aifootpredictor.com/widget/
 * Description:       Football match probabilities on your site: free widgets (shortcode, block, sidebar widget) and, for AI Football Predictor Pro, match previews written for your site and imported automatically.
 * Version:           1.1.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            AI Football Predictor
 * Author URI:        https://aifootpredictor.com/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ai-football-predictor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AIFP_VERSION', '1.1.0' );
define( 'AIFP_SITE', 'https://aifootpredictor.com/' );
define( 'AIFP_FEED_HOST', 'afp-blog-production.up.railway.app' );

/** French or English, from the site language. */
function aifp_fr() {
	return 0 === strpos( determine_locale(), 'fr' );
}
function aifp_t( $fr, $en ) {
	return aifp_fr() ? $fr : $en;
}

/* -------------------------------------------------------------------------
 * 1. Free widgets: [aifp] shortcode, block and sidebar widget
 * ---------------------------------------------------------------------- */

/**
 * Widget HTML (the official embed code, rendered server side).
 *
 * @param array $a type (matches|live|match|team|table|articles), lang, competitions, team, match, n, theme.
 */
function aifp_widget_html( $a ) {
	$a = shortcode_atts(
		array(
			'type'         => 'matches',
			'lang'         => aifp_fr() ? 'fr' : 'en',
			'competitions' => '',
			'team'         => '',
			'match'        => '',
			'n'            => '6',
			'theme'        => 'dark',
		),
		$a,
		'aifp'
	);
	$fr    = 'fr' === $a['lang'];
	$type  = in_array( $a['type'], array( 'matches', 'live', 'match', 'team', 'table', 'articles', 'badge' ), true ) ? $a['type'] : 'matches';
	$attrs = ' data-lang="' . esc_attr( $fr ? 'fr' : 'en' ) . '"';
	if ( 'matches' !== $type ) {
		$attrs .= ' data-type="' . esc_attr( $type ) . '"';
	}
	if ( '' !== $a['competitions'] ) {
		$attrs .= ' data-lg="' . esc_attr( preg_replace( '/[^A-Za-z0-9_,]/', '', $a['competitions'] ) ) . '"';
	}
	if ( '' !== $a['team'] ) {
		$attrs .= ' data-team="' . esc_attr( $a['team'] ) . '"';
	}
	if ( '' !== $a['match'] ) {
		$attrs .= ' data-match="' . esc_attr( preg_replace( '/[^0-9]/', '', $a['match'] ) ) . '"';
	}
	$attrs .= ' data-n="' . esc_attr( max( 1, min( 20, absint( $a['n'] ) ) ) ) . '"';
	if ( 'light' === $a['theme'] ) {
		$attrs .= ' data-theme="light"';
	}
	$style = trim( (string) get_option( 'aifp_style_key', '' ) );
	if ( '' !== $style ) {
		$attrs .= ' data-p="' . esc_attr( preg_replace( '/[^A-Za-z0-9_-]/', '', $style ) ) . '"';
	}
	wp_enqueue_script( 'aifp-embed', AIFP_SITE . 'embed.js', array(), AIFP_VERSION, array( 'in_footer' => true, 'strategy' => 'async' ) );
	$label = $fr ? 'Probabilités foot par AI Football Predictor' : 'Football probabilities by AI Football Predictor';
	return '<div class="afp-widget"' . $attrs . '><a href="' . esc_url( AIFP_SITE . ( $fr ? 'fr/' : '' ) ) . '">' . esc_html( $label ) . '</a></div>';
}
add_shortcode( 'aifp', 'aifp_widget_html' );

/** Block (no build step: plain JS editor script, server-side render). */
function aifp_register_block() {
	wp_register_script(
		'aifp-block-editor',
		plugins_url( 'blocks/editor.js', __FILE__ ),
		array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-server-side-render' ),
		AIFP_VERSION,
		true
	);
	wp_localize_script( 'aifp-block-editor', 'AIFP_I18N', array( 'fr' => aifp_fr() ) );
	register_block_type(
		'aifp/widget',
		array(
			'editor_script'   => 'aifp-block-editor',
			'render_callback' => 'aifp_widget_html',
			'attributes'      => array(
				'type'         => array( 'type' => 'string', 'default' => 'matches' ),
				'lang'         => array( 'type' => 'string', 'default' => aifp_fr() ? 'fr' : 'en' ),
				'competitions' => array( 'type' => 'string', 'default' => '' ),
				'team'         => array( 'type' => 'string', 'default' => '' ),
				'n'            => array( 'type' => 'string', 'default' => '6' ),
				'theme'        => array( 'type' => 'string', 'default' => 'dark' ),
			),
		)
	);
}
add_action( 'init', 'aifp_register_block' );

/** Sidebar widget. */
class AIFP_Sidebar_Widget extends WP_Widget {
	public function __construct() {
		parent::__construct( 'aifp_widget', 'AI Football Predictor', array( 'description' => aifp_t( 'Les probabilités des prochains matchs de foot.', 'Probabilities of the next football matches.' ) ) );
	}
	public function widget( $args, $instance ) {
		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo aifp_widget_html( $instance ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	public function form( $instance ) {
		$f = array(
			'title'        => aifp_t( 'Titre', 'Title' ),
			'competitions' => aifp_t( 'Compétitions (codes, ex. F1,CL)', 'Competitions (codes, e.g. E0,CL)' ),
			'team'         => aifp_t( 'Club (facultatif)', 'Club (optional)' ),
			'n'            => aifp_t( 'Nombre de matchs', 'Number of matches' ),
		);
		foreach ( $f as $k => $label ) {
			printf( '<p><label for="%1$s">%2$s</label><input class="widefat" id="%1$s" name="%3$s" value="%4$s"></p>', esc_attr( $this->get_field_id( $k ) ), esc_html( $label ), esc_attr( $this->get_field_name( $k ) ), esc_attr( isset( $instance[ $k ] ) ? $instance[ $k ] : ( 'n' === $k ? '6' : '' ) ) );
		}
		$th = isset( $instance['theme'] ) ? $instance['theme'] : 'dark';
		printf( '<p><label for="%1$s">%2$s</label> <select id="%1$s" name="%3$s"><option value="dark"%4$s>%5$s</option><option value="light"%6$s>%7$s</option></select></p>', esc_attr( $this->get_field_id( 'theme' ) ), esc_html( aifp_t( 'Thème', 'Theme' ) ), esc_attr( $this->get_field_name( 'theme' ) ), selected( $th, 'dark', false ), esc_html( aifp_t( 'Sombre', 'Dark' ) ), selected( $th, 'light', false ), esc_html( aifp_t( 'Clair', 'Light' ) ) );
	}
	public function update( $new, $old ) {
		return array(
			'title'        => sanitize_text_field( $new['title'] ),
			'competitions' => sanitize_text_field( $new['competitions'] ),
			'team'         => sanitize_text_field( $new['team'] ),
			'n'            => (string) max( 1, min( 20, absint( $new['n'] ) ) ),
			'theme'        => 'light' === $new['theme'] ? 'light' : 'dark',
		);
	}
}
add_action(
	'widgets_init',
	function () {
		register_widget( 'AIFP_Sidebar_Widget' );
	}
);

/* -------------------------------------------------------------------------
 * 2. Pro: match previews written for this site, imported every hour
 * ---------------------------------------------------------------------- */

register_activation_hook(
	__FILE__,
	function () {
		if ( ! wp_next_scheduled( 'aifp_import' ) ) {
			wp_schedule_event( time() + 300, 'hourly', 'aifp_import' );
		}
	}
);
register_deactivation_hook(
	__FILE__,
	function () {
		wp_clear_scheduled_hook( 'aifp_import' );
	}
);
add_action( 'aifp_import', 'aifp_import' );

/** Only accepts the official feed address. */
function aifp_feed_url() {
	$u = trim( (string) get_option( 'aifp_feed_url', '' ) );
	if ( '' === $u ) {
		return '';
	}
	$p = wp_parse_url( $u );
	if ( empty( $p['host'] ) || AIFP_FEED_HOST !== $p['host'] || empty( $p['query'] ) ) {
		return '';
	}
	parse_str( $p['query'], $q );
	if ( empty( $q['t'] ) ) {
		return '';
	}
	return 'https://' . AIFP_FEED_HOST . '/api/pro/feed?t=' . rawurlencode( preg_replace( '/[^a-f0-9]/', '', $q['t'] ) );
}

/** The Pro feed token (it also identifies the Pro account for the widget style). */
function aifp_feed_token() {
	$u = aifp_feed_url();
	return '' === $u ? '' : substr( $u, strpos( $u, '?t=' ) + 3 );
}

/**
 * Pro widget style (colours and logo), stored on AI Football Predictor and applied to every widget through data-p.
 *
 * @param array|null $body Null to read, an array to save.
 * @return array{ok:bool,error?:string,style?:array}
 */
function aifp_style_api( $body = null ) {
	$t = aifp_feed_token();
	if ( '' === $t ) {
		return array( 'ok' => false, 'error' => 'feed' );
	}
	$url  = 'https://' . AIFP_FEED_HOST . '/api/pro/wstyle?t=' . rawurlencode( $t );
	$args = array( 'timeout' => 25, 'headers' => array( 'Accept' => 'application/json' ) );
	if ( null === $body ) {
		$r = wp_remote_get( $url, $args );
	} else {
		$args['headers']['Content-Type'] = 'application/json';
		$args['body']                    = wp_json_encode( $body );
		$r                               = wp_remote_post( $url, $args );
	}
	if ( is_wp_error( $r ) ) {
		return array( 'ok' => false, 'error' => 'network' );
	}
	$j = json_decode( wp_remote_retrieve_body( $r ), true );
	if ( ! is_array( $j ) ) {
		return array( 'ok' => false, 'error' => 'network' );
	}
	if ( isset( $j['prem'] ) && ! $j['prem'] ) {
		return array( 'ok' => false, 'error' => 'pro_only' );
	}
	if ( empty( $j['ok'] ) ) {
		return array( 'ok' => false, 'error' => isset( $j['error'] ) ? (string) $j['error'] : 'error' );
	}
	$st = isset( $j['style'] ) && is_array( $j['style'] ) ? $j['style'] : array();
	if ( ! empty( $st['token'] ) ) {
		update_option( 'aifp_style', $st, false );
		update_option( 'aifp_style_key', sanitize_text_field( $st['token'] ), false );
	}
	return array( 'ok' => true, 'style' => $st );
}

/**
 * Imports the new articles of the Pro feed, and adds the result to the ones already imported
 * (only if the post was not edited by hand since).
 *
 * @return array{ok:bool,msg:string,new:int,upd:int}
 */
function aifp_import() {
	$url = aifp_feed_url();
	if ( '' === $url ) {
		return aifp_log( false, aifp_t( 'Aucune adresse de flux valide.', 'No valid feed address.' ) );
	}
	$r = wp_remote_get( $url, array( 'timeout' => 20 ) );
	if ( is_wp_error( $r ) ) {
		return aifp_log( false, $r->get_error_message() );
	}
	$code = wp_remote_retrieve_response_code( $r );
	$j    = json_decode( wp_remote_retrieve_body( $r ), true );
	if ( 403 === $code ) {
		return aifp_log( false, aifp_t( 'Votre abonnement AI Football Predictor Pro n’est pas actif.', 'Your AI Football Predictor Pro subscription is not active.' ) );
	}
	if ( 200 !== $code || ! is_array( $j ) || ! isset( $j['articles'] ) ) {
		return aifp_log( false, aifp_t( 'Flux introuvable. Vérifiez l’adresse dans votre Espace Pro.', 'Feed not found. Check the address in your Pro space.' ) . ' (HTTP ' . (int) $code . ')' );
	}
	$status = 'publish' === get_option( 'aifp_status', 'draft' ) ? 'publish' : 'draft';
	$cat    = absint( get_option( 'aifp_category', 0 ) );
	$author = absint( get_option( 'aifp_author', 0 ) );
	$thumb  = absint( get_option( 'aifp_thumbnail', 0 ) );
	$new    = 0;
	$upd    = 0;
	foreach ( array_reverse( $j['articles'] ) as $a ) {
		if ( empty( $a['id'] ) || empty( $a['title'] ) || empty( $a['html'] ) ) {
			continue;
		}
		$html  = wp_kses_post( $a['html'] );
		$found = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => 'any',
				'meta_key'       => '_aifp_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => (string) $a['id'], // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);
		if ( $found ) {
			$pid = $found[0];
			$cur = get_post_field( 'post_content', $pid );
			if ( $cur !== $html && md5( $cur ) === get_post_meta( $pid, '_aifp_hash', true ) ) {
				wp_update_post( array( 'ID' => $pid, 'post_content' => $html ) );
				update_post_meta( $pid, '_aifp_hash', md5( get_post_field( 'post_content', $pid ) ) );
				++$upd;
			}
			continue;
		}
		$post = array(
			'post_title'   => sanitize_text_field( $a['title'] ),
			'post_content' => $html,
			'post_excerpt' => isset( $a['lede'] ) ? sanitize_text_field( $a['lede'] ) : '',
			'post_status'  => $status,
			'post_type'    => 'post',
		);
		if ( $cat ) {
			$post['post_category'] = array( $cat );
		}
		if ( $author ) {
			$post['post_author'] = $author;
		}
		$pid = wp_insert_post( $post, true );
		if ( is_wp_error( $pid ) ) {
			continue;
		}
		if ( ! empty( $a['tags'] ) && is_array( $a['tags'] ) ) {
			wp_set_post_tags( $pid, array_map( 'sanitize_text_field', $a['tags'] ) );
		}
		if ( $thumb ) {
			set_post_thumbnail( $pid, $thumb );
		}
		update_post_meta( $pid, '_aifp_id', (string) $a['id'] );
		update_post_meta( $pid, '_aifp_hash', md5( get_post_field( 'post_content', $pid ) ) );
		++$new;
	}
	return aifp_log( true, sprintf( aifp_t( '%1$d nouvel(s) article(s), %2$d mis à jour avec le résultat.', '%1$d new article(s), %2$d updated with the result.' ), $new, $upd ), $new, $upd );
}
function aifp_log( $ok, $msg, $new = 0, $upd = 0 ) {
	$r = array(
		'ok'  => $ok,
		'msg' => $msg,
		'new' => $new,
		'upd' => $upd,
		'at'  => time(),
	);
	update_option( 'aifp_last_import', $r, false );
	return $r;
}

/* -------------------------------------------------------------------------
 * 3. Admin page (own menu entry "AI Football Predictor")
 * ---------------------------------------------------------------------- */

function aifp_admin_url( $args = array() ) {
	return add_query_arg( array_merge( array( 'page' => 'aifp' ), $args ), admin_url( 'admin.php' ) );
}
add_action(
	'admin_menu',
	function () {
		$icon = 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><rect x="3" y="3" width="14" height="14" fill="none" stroke="black" stroke-width="2"/><rect x="5.5" y="5" width="11" height="11" fill="none" stroke="black" stroke-width="1" stroke-dasharray="1.5 1.5" transform="rotate(8 11 10.5)"/><circle cx="10" cy="10" r="2.2" fill="black"/></svg>' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		add_menu_page( 'AI Football Predictor', 'AI Football', 'manage_options', 'aifp', 'aifp_settings_page', $icon, 58 );
	}
);
add_action(
	'admin_enqueue_scripts',
	function ( $hook ) {
		if ( 'toplevel_page_aifp' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'aifp-admin', plugins_url( 'assets/admin.css', __FILE__ ), array(), AIFP_VERSION );
		wp_enqueue_media();
		wp_enqueue_script( 'aifp-admin', plugins_url( 'assets/admin.js', __FILE__ ), array(), AIFP_VERSION, true );
	}
);
add_action(
	'admin_init',
	function () {
		register_setting( 'aifp', 'aifp_feed_url', array( 'type' => 'string', 'sanitize_callback' => 'esc_url_raw' ) );
		register_setting( 'aifp', 'aifp_status', array( 'type' => 'string', 'sanitize_callback' => function ( $v ) { return 'publish' === $v ? 'publish' : 'draft'; } ) );
		register_setting( 'aifp', 'aifp_category', array( 'type' => 'integer', 'sanitize_callback' => 'absint' ) );
		register_setting( 'aifp', 'aifp_author', array( 'type' => 'integer', 'sanitize_callback' => 'absint' ) );
		register_setting( 'aifp', 'aifp_thumbnail', array( 'type' => 'integer', 'sanitize_callback' => 'absint' ) );
	}
);
add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	function ( $links ) {
		array_unshift( $links, '<a href="' . esc_url( aifp_admin_url() ) . '">' . esc_html( aifp_t( 'Réglages', 'Settings' ) ) . '</a>' );
		return $links;
	}
);
add_action(
	'admin_post_aifp_import_now',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'forbidden' );
		}
		check_admin_referer( 'aifp_import_now' );
		aifp_import();
		wp_safe_redirect( aifp_admin_url( array( 'imported' => 1 ) ) );
		exit;
	}
);
add_action(
	'admin_post_aifp_save_style',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'forbidden' );
		}
		check_admin_referer( 'aifp_save_style' );
		$col  = function ( $k ) {
			$v = isset( $_POST[ $k ] ) ? sanitize_hex_color( wp_unslash( $_POST[ $k ] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			return $v ? strtolower( $v ) : null;
		};
		$body = array( 'bg' => $col( 'aifp_bg' ), 'txt' => $col( 'aifp_txt' ), 'acc' => $col( 'aifp_acc' ) );
		$lid  = isset( $_POST['aifp_logo_id'] ) ? absint( $_POST['aifp_logo_id'] ) : 0;
		$old  = (array) get_option( 'aifp_style', array() );
		if ( $lid && (int) get_option( 'aifp_logo_id', 0 ) === $lid && ! empty( $old['logo'] ) ) {
			$body['logo'] = (string) $old['logo'];
		} elseif ( $lid ) {
			/* The logo is sent as an image (the smallest size that fits), so it works even on a site without https. */
			$file = get_attached_file( $lid );
			$mime = (string) get_post_mime_type( $lid );
			foreach ( array( 'medium', 'thumbnail' ) as $size ) {
				$i = image_get_intermediate_size( $lid, $size );
				if ( $i && ! empty( $i['path'] ) ) {
					$up   = wp_get_upload_dir();
					$file = trailingslashit( $up['basedir'] ) . $i['path'];
					$mime = ! empty( $i['mime-type'] ) ? $i['mime-type'] : $mime;
					break;
				}
			}
			if ( ! in_array( $mime, array( 'image/png', 'image/jpeg', 'image/webp' ), true ) ) {
				wp_safe_redirect( aifp_admin_url( array( 'style' => 'logo_type' ) ) . '#aifp-style' );
				exit;
			}
			if ( ! $file || ! is_readable( $file ) || filesize( $file ) > 380000 ) {
				wp_safe_redirect( aifp_admin_url( array( 'style' => 'logo_size' ) ) . '#aifp-style' );
				exit;
			}
			$body['logoData'] = 'data:' . $mime . ';base64,' . base64_encode( file_get_contents( $file ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		} else {
			$body['logo'] = '';
		}
		$r = aifp_style_api( $body );
		if ( $r['ok'] ) {
			update_option( 'aifp_logo_id', $lid, false );
		}
		wp_safe_redirect( aifp_admin_url( array( 'style' => $r['ok'] ? 'saved' : $r['error'] ) ) . '#aifp-style' );
		exit;
	}
);
/* The Settings API redirects to options-general.php by default: come back to our page. */
add_filter(
	'wp_redirect',
	function ( $loc ) {
		if ( false !== strpos( $loc, 'options-general.php?page=aifp' ) ) {
			return aifp_admin_url( array( 'settings-updated' => 'true' ) );
		}
		return $loc;
	}
);

function aifp_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$fr     = aifp_fr();
	$last   = get_option( 'aifp_last_import' );
	$feed   = aifp_feed_url();
	$site   = AIFP_SITE . ( $fr ? 'fr/' : '' );
	$state  = '' === $feed ? 'free' : ( is_array( $last ) && ! $last['ok'] ? 'warn' : 'ok' );
	$pill   = array(
		'free' => array( '', aifp_t( 'Version gratuite', 'Free version' ) ),
		'ok'   => array( 'ok', aifp_t( 'Pro connecté', 'Pro connected' ) ),
		'warn' => array( 'warn', aifp_t( 'Pro : à vérifier', 'Pro: needs attention' ) ),
	)[ $state ];
	$comps  = array( 'F1' => 'Ligue 1', 'E0' => 'Premier League', 'SP1' => 'LaLiga', 'I1' => 'Serie A', 'D1' => 'Bundesliga', 'CL' => aifp_t( 'Ligue des champions', 'Champions League' ), 'EL' => 'Europa League', 'P1' => 'Portugal', 'N1' => aifp_t( 'Pays-Bas', 'Netherlands' ) );
	$recent = get_posts( array( 'post_type' => 'post', 'post_status' => 'any', 'meta_key' => '_aifp_id', 'posts_per_page' => 5, 'orderby' => 'date', 'order' => 'DESC' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
	?>
	<div class="wrap aifp">
		<?php if ( isset( $_GET['settings-updated'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-success is-dismissible"><p><?php echo esc_html( aifp_t( 'Réglages enregistrés.', 'Settings saved.' ) ); ?></p></div>
		<?php endif; ?>
		<div class="aifp-hero">
			<img src="<?php echo esc_url( plugins_url( 'assets/logo.svg', __FILE__ ) ); ?>" alt="">
			<div class="aifp-grow">
				<span class="aifp-pill <?php echo esc_attr( $pill[0] ); ?>"><i></i><?php echo esc_html( $pill[1] ); ?></span>
				<h1>AI Football Predictor</h1>
				<p><?php echo esc_html( aifp_t( 'Les probabilités de chaque match de foot sur votre site, mises à jour toutes seules. Et avec Pro, des avant-matchs écrits pour vous, publiés chaque jour.', 'The probability of every football match on your site, updated on its own. And with Pro, match previews written for you, published every day.' ) ); ?></p>
			</div>
			<div class="aifp-act">
				<?php if ( 'free' === $state ) : ?>
					<a class="aifp-btn pri" href="<?php echo esc_url( $site . 'pro/?src=wp' ); ?>" target="_blank" rel="noopener"><?php echo esc_html( aifp_t( 'Découvrir Pro', 'Discover Pro' ) ); ?></a>
				<?php else : ?>
					<a class="aifp-btn pri" href="<?php echo esc_url( $site . '?tab=space&src=wp' ); ?>" target="_blank" rel="noopener"><?php echo esc_html( aifp_t( 'Mon Espace Pro', 'My Pro space' ) ); ?></a>
				<?php endif; ?>
				<a class="aifp-btn" href="<?php echo esc_url( $site . 'wordpress/' ); ?>" target="_blank" rel="noopener"><?php echo esc_html( aifp_t( 'Guide', 'Guide' ) ); ?></a>
			</div>
		</div>

		<div class="aifp-grid">
			<div class="aifp-card" id="aifp-builder" data-lang="<?php echo esc_attr( $fr ? 'fr' : 'en' ); ?>" data-p="<?php echo esc_attr( (string) get_option( 'aifp_style_key', '' ) ); ?>" data-copy="<?php echo esc_attr( aifp_t( 'Copier', 'Copy' ) ); ?>" data-copied="<?php echo esc_attr( aifp_t( 'Copié ✓', 'Copied ✓' ) ); ?>">
				<h2><?php echo esc_html( aifp_t( 'Widgets', 'Widgets' ) ); ?> <span class="tag"><?php echo esc_html( aifp_t( 'gratuit', 'free' ) ); ?></span></h2>
				<p class="lead"><?php echo esc_html( aifp_t( 'Réglez votre widget, copiez le shortcode et collez-le dans une page. Vous pouvez aussi utiliser le bloc « AI Football Predictor » ou le widget de barre latérale.', 'Set up your widget, copy the shortcode and paste it into a page. You can also use the “AI Football Predictor” block or the sidebar widget.' ) ); ?></p>
				<div class="aifp-f">
					<div><label class="l" for="aifp-b-type"><?php echo esc_html( aifp_t( 'Affichage', 'Display' ) ); ?></label>
						<select id="aifp-b-type"><option value="matches"><?php echo esc_html( aifp_t( 'Prochains matchs', 'Next matches' ) ); ?></option><option value="live"><?php echo esc_html( aifp_t( 'Matchs en direct', 'Live matches' ) ); ?></option><option value="table"><?php echo esc_html( aifp_t( 'Classement probable', 'Projected table' ) ); ?></option><option value="team"><?php echo esc_html( aifp_t( 'Un club', 'One club' ) ); ?></option><option value="articles"><?php echo esc_html( aifp_t( 'Derniers avant-matchs', 'Latest previews' ) ); ?></option></select></div>
					<div><label class="l" for="aifp-b-team"><?php echo esc_html( aifp_t( 'Club (facultatif)', 'Club (optional)' ) ); ?></label>
						<input type="text" id="aifp-b-team" placeholder="<?php echo esc_attr( aifp_t( 'ex. Lyon', 'e.g. Arsenal' ) ); ?>"></div>
					<div class="full"><label class="l" for="aifp-b-comps"><?php echo esc_html( aifp_t( 'Compétitions', 'Competitions' ) ); ?></label>
						<input type="text" id="aifp-b-comps" placeholder="F1,CL">
						<div class="aifp-chips"><?php foreach ( $comps as $c => $n ) : ?><button type="button" data-c="<?php echo esc_attr( $c ); ?>" title="<?php echo esc_attr( $n ); ?>"><?php echo esc_html( $n ); ?></button><?php endforeach; ?></div></div>
					<div><label class="l" for="aifp-b-n"><?php echo esc_html( aifp_t( 'Nombre de matchs', 'Number of matches' ) ); ?></label>
						<input type="number" id="aifp-b-n" min="1" max="20" value="6"></div>
					<div><label class="l" for="aifp-b-lang"><?php echo esc_html( aifp_t( 'Langue', 'Language' ) ); ?></label>
						<select id="aifp-b-lang"><option value="fr" <?php selected( $fr ); ?>>Français</option><option value="en" <?php selected( ! $fr ); ?>>English</option></select></div>
					<div><label class="l" for="aifp-b-theme"><?php echo esc_html( aifp_t( 'Thème', 'Theme' ) ); ?></label>
						<select id="aifp-b-theme"><option value="dark"><?php echo esc_html( aifp_t( 'Sombre', 'Dark' ) ); ?></option><option value="light"><?php echo esc_html( aifp_t( 'Clair', 'Light' ) ); ?></option></select></div>
				</div>
				<div class="aifp-code"><code id="aifp-b-code">[aifp]</code><button type="button" id="aifp-b-copy"><?php echo esc_html( aifp_t( 'Copier', 'Copy' ) ); ?></button></div>
				<div class="aifp-prev"><div class="cap"><?php echo esc_html( aifp_t( 'Aperçu en direct', 'Live preview' ) ); ?></div><div id="aifp-b-prev"></div></div>
			</div>

			<div class="aifp-card">
				<h2><?php echo esc_html( aifp_t( 'Articles pour votre site', 'Articles for your site' ) ); ?> <span class="tag pro">Pro</span></h2>
				<p class="lead"><?php echo esc_html( aifp_t( 'Jusqu’à 10 avant-matchs par jour, écrits pour votre site uniquement, importés ici toutes les heures. Le résultat s’ajoute après le match.', 'Up to 10 match previews a day, written for your site only, imported here every hour. The result is added after the match.' ) ); ?></p>
				<?php if ( 'free' === $state ) : ?>
					<div class="aifp-up">
						<strong><?php echo esc_html( aifp_t( 'Avec AI Football Predictor Pro', 'With AI Football Predictor Pro' ) ); ?></strong>
						<ul>
							<li><?php echo esc_html( aifp_t( 'Du contenu foot chaque jour, sans rien écrire', 'Football content every day, without writing a line' ) ); ?></li>
							<li><?php echo esc_html( aifp_t( 'Vos widgets à vos couleurs, avec votre logo, sans pub', 'Your widgets in your colours, with your logo, ad-free' ) ); ?></li>
							<li><?php echo esc_html( aifp_t( 'L’API à 50 000 requêtes par jour', 'The API at 50,000 requests a day' ) ); ?></li>
						</ul>
						<a class="aifp-btn pri" href="<?php echo esc_url( $site . 'pro/?src=wp' ); ?>" target="_blank" rel="noopener"><?php echo esc_html( aifp_t( 'Essayer 7 jours gratuits', 'Try 7 days free' ) ); ?></a>
					</div>
				<?php endif; ?>
				<form method="post" action="options.php" style="margin-top:16px">
					<?php settings_fields( 'aifp' ); ?>
					<div class="aifp-f">
						<div class="full"><label class="l" for="aifp_feed_url"><?php echo esc_html( aifp_t( 'Adresse de votre flux', 'Your feed address' ) ); ?></label>
							<input type="url" id="aifp_feed_url" name="aifp_feed_url" value="<?php echo esc_attr( get_option( 'aifp_feed_url', '' ) ); ?>" placeholder="https://<?php echo esc_attr( AIFP_FEED_HOST ); ?>/api/pro/feed?t=…">
							<div class="hint"><?php echo esc_html( aifp_t( 'Dans votre Espace Pro, bouton « JSON » sous « Articles pour votre site ».', 'In your Pro space, “JSON” button under “Articles for your site”.' ) ); ?></div></div>
						<div><label class="l" for="aifp_status"><?php echo esc_html( aifp_t( 'Publication', 'Publishing' ) ); ?></label>
							<select id="aifp_status" name="aifp_status"><option value="draft" <?php selected( get_option( 'aifp_status', 'draft' ), 'draft' ); ?>><?php echo esc_html( aifp_t( 'En brouillon', 'As drafts' ) ); ?></option><option value="publish" <?php selected( get_option( 'aifp_status', 'draft' ), 'publish' ); ?>><?php echo esc_html( aifp_t( 'Publier directement', 'Publish right away' ) ); ?></option></select></div>
						<div><label class="l" for="aifp_category"><?php echo esc_html( aifp_t( 'Catégorie', 'Category' ) ); ?></label>
							<?php wp_dropdown_categories( array( 'name' => 'aifp_category', 'id' => 'aifp_category', 'selected' => absint( get_option( 'aifp_category', 0 ) ), 'show_option_none' => aifp_t( 'Par défaut', 'Default' ), 'option_none_value' => 0, 'hide_empty' => false ) ); ?></div>
						<div><label class="l" for="aifp_author"><?php echo esc_html( aifp_t( 'Auteur', 'Author' ) ); ?></label>
							<?php wp_dropdown_users( array( 'name' => 'aifp_author', 'id' => 'aifp_author', 'selected' => absint( get_option( 'aifp_author', 0 ) ), 'show_option_none' => aifp_t( 'Par défaut', 'Default' ), 'option_none_value' => 0, 'capability' => array( 'edit_posts' ) ) ); ?></div>
						<div><label class="l" for="aifp_thumbnail"><?php echo esc_html( aifp_t( 'Image à la une (ID)', 'Featured image (ID)' ) ); ?></label>
							<input type="number" min="0" id="aifp_thumbnail" name="aifp_thumbnail" value="<?php echo esc_attr( (string) absint( get_option( 'aifp_thumbnail', 0 ) ) ); ?>"></div>
					</div>
					<div class="aifp-row"><button type="submit" class="aifp-btn pri"><?php echo esc_html( aifp_t( 'Enregistrer', 'Save' ) ); ?></button></div>
				</form>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="aifp-row">
					<input type="hidden" name="action" value="aifp_import_now">
					<?php wp_nonce_field( 'aifp_import_now' ); ?>
					<button type="submit" class="aifp-btn"><?php echo esc_html( aifp_t( 'Importer maintenant', 'Import now' ) ); ?></button>
				</form>
				<?php if ( is_array( $last ) ) : ?>
					<div class="aifp-log <?php echo $last['ok'] ? 'ok' : 'ko'; ?>"><?php echo esc_html( ( $last['ok'] ? '✓ ' : '⚠ ' ) . wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $last['at'] ) . ' · ' . $last['msg'] ); ?></div>
				<?php endif; ?>
				<?php if ( $recent ) : ?>
					<ul class="aifp-pro-list">
						<?php foreach ( $recent as $p ) : ?>
							<li><a href="<?php echo esc_url( get_edit_post_link( $p->ID ) ); ?>"><?php echo esc_html( get_the_title( $p ) ); ?></a><span><?php echo esc_html( 'publish' === $p->post_status ? aifp_t( 'publié', 'published' ) : aifp_t( 'brouillon', 'draft' ) ); ?></span></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>
		</div>

		<?php
		$feed_ok = '' !== $feed;
		$st      = (array) get_option( 'aifp_style', array() );
		if ( $feed_ok && empty( $st['token'] ) && false === get_transient( 'aifp_style_sync' ) ) {
			set_transient( 'aifp_style_sync', 1, HOUR_IN_SECONDS );
			$sync = aifp_style_api();
			if ( $sync['ok'] ) {
				$st = (array) get_option( 'aifp_style', array() );
			}
		}
		$bg     = ! empty( $st['bg'] ) ? $st['bg'] : '#06090e';
		$tx     = ! empty( $st['txt'] ) ? $st['txt'] : '#e6edf6';
		$ac     = ! empty( $st['acc'] ) ? $st['acc'] : '#3ee0a8';
		$lid    = absint( get_option( 'aifp_logo_id', 0 ) );
		$lurl   = $lid ? wp_get_attachment_image_url( $lid, 'thumbnail' ) : ( ! empty( $st['logo'] ) ? $st['logo'] : '' );
		$msg    = isset( $_GET['style'] ) ? sanitize_key( wp_unslash( $_GET['style'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$msgs   = array(
			'saved'     => array( 'ok', aifp_t( 'Style enregistré : tous vos widgets sont à vos couleurs.', 'Style saved: all your widgets now use your colours.' ) ),
			'pro_only'  => array( 'ko', aifp_t( 'Votre abonnement Pro n’est pas actif.', 'Your Pro subscription is not active.' ) ),
			'feed'      => array( 'ko', aifp_t( 'Collez d’abord l’adresse de votre flux Pro ci-dessus.', 'Paste your Pro feed address above first.' ) ),
			'unknown_feed' => array( 'ko', aifp_t( 'Adresse du flux inconnue : recopiez-la depuis votre Espace Pro.', 'Unknown feed address: copy it again from your Pro space.' ) ),
			'logo_type' => array( 'ko', aifp_t( 'Logo : utilisez une image PNG, JPG ou WebP.', 'Logo: use a PNG, JPG or WebP image.' ) ),
			'logo_size' => array( 'ko', aifp_t( 'Logo trop lourd : choisissez une image plus légère.', 'Logo too large: pick a lighter image.' ) ),
		);
		$themes = array( array( '#06090e', '#e6edf6', '#3ee0a8' ), array( '#ffffff', '#1d2327', '#2271b1' ), array( '#0b1d3a', '#f1f5fb', '#ffcc00' ), array( '#1a0a0a', '#fbeeee', '#e63946' ), array( '#0f2417', '#ecf8f0', '#4ade80' ), array( '#f7f3ea', '#2b2118', '#c2410c' ) );
		?>
		<div class="aifp-card aifp-style" id="aifp-style">
			<h2><?php echo esc_html( aifp_t( 'Vos couleurs et votre logo', 'Your colours and logo' ) ); ?> <span class="tag pro">Pro</span></h2>
			<p class="lead"><?php echo esc_html( aifp_t( 'Habillez tous vos widgets aux couleurs de votre site, avec votre logo et sans pub. Le changement s’applique partout, sans toucher à vos shortcodes.', 'Dress every widget in your site’s colours, with your logo and no ads. The change applies everywhere, without touching your shortcodes.' ) ); ?></p>
			<?php if ( $msg && isset( $msgs[ $msg ] ) ) : ?>
				<div class="aifp-log <?php echo esc_attr( $msgs[ $msg ][0] ); ?>"><?php echo esc_html( ( 'ok' === $msgs[ $msg ][0] ? '✓ ' : '⚠ ' ) . $msgs[ $msg ][1] ); ?></div>
			<?php elseif ( $msg ) : ?>
				<div class="aifp-log ko"><?php echo esc_html( '⚠ ' . aifp_t( 'Enregistrement impossible pour le moment, réessayez.', 'Could not save right now, please try again.' ) ); ?></div>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="aifp-sg<?php echo $feed_ok ? '' : ' locked'; ?>">
				<input type="hidden" name="action" value="aifp_save_style">
				<?php wp_nonce_field( 'aifp_save_style' ); ?>
				<div>
					<label class="l"><?php echo esc_html( aifp_t( 'Thèmes tout faits', 'Ready-made themes' ) ); ?></label>
					<div class="aifp-th">
						<?php foreach ( $themes as $t ) : ?>
							<button type="button" data-t="<?php echo esc_attr( implode( ',', $t ) ); ?>" style="background:<?php echo esc_attr( $t[0] ); ?>" aria-label="<?php echo esc_attr( implode( ' ', $t ) ); ?>"><i style="background:<?php echo esc_attr( $t[2] ); ?>"></i></button>
						<?php endforeach; ?>
					</div>
					<div class="aifp-sw">
						<label><input type="color" name="aifp_bg" id="aifp-c-bg" value="<?php echo esc_attr( $bg ); ?>"><span><small><?php echo esc_html( aifp_t( 'Fond', 'Background' ) ); ?></small><b><?php echo esc_html( $bg ); ?></b></span></label>
						<label><input type="color" name="aifp_txt" id="aifp-c-txt" value="<?php echo esc_attr( $tx ); ?>"><span><small><?php echo esc_html( aifp_t( 'Texte', 'Text' ) ); ?></small><b><?php echo esc_html( $tx ); ?></b></span></label>
						<label><input type="color" name="aifp_acc" id="aifp-c-acc" value="<?php echo esc_attr( $ac ); ?>"><span><small><?php echo esc_html( aifp_t( 'Accent', 'Accent' ) ); ?></small><b><?php echo esc_html( $ac ); ?></b></span></label>
					</div>
					<label class="l"><?php echo esc_html( aifp_t( 'Logo', 'Logo' ) ); ?></label>
					<div class="aifp-logo">
						<span class="aifp-logo-img" id="aifp-logo-img"><?php if ( $lurl ) : ?><img src="<?php echo esc_url( $lurl ); ?>" alt=""><?php endif; ?></span>
						<input type="hidden" name="aifp_logo_id" id="aifp-logo-id" value="<?php echo esc_attr( (string) $lid ); ?>">
						<button type="button" class="aifp-btn" id="aifp-logo-pick" data-title="<?php echo esc_attr( aifp_t( 'Choisir votre logo', 'Choose your logo' ) ); ?>" data-button="<?php echo esc_attr( aifp_t( 'Utiliser ce logo', 'Use this logo' ) ); ?>"><?php echo esc_html( aifp_t( 'Choisir dans la médiathèque', 'Choose from the Media Library' ) ); ?></button>
						<button type="button" class="aifp-btn" id="aifp-logo-del"<?php echo $lurl ? '' : ' hidden'; ?>><?php echo esc_html( aifp_t( 'Retirer', 'Remove' ) ); ?></button>
					</div>
					<div class="hint"><?php echo esc_html( aifp_t( 'Un logo carré marche le mieux (PNG avec fond transparent).', 'A square logo works best (PNG with a transparent background).' ) ); ?></div>
					<div class="aifp-row">
						<?php if ( $feed_ok ) : ?>
							<button type="submit" class="aifp-btn pri"><?php echo esc_html( aifp_t( 'Enregistrer le style', 'Save the style' ) ); ?></button>
						<?php else : ?>
							<a class="aifp-btn pri" href="<?php echo esc_url( $site . 'pro/?src=wpstyle' ); ?>" target="_blank" rel="noopener"><?php echo esc_html( aifp_t( 'Débloquer avec Pro', 'Unlock with Pro' ) ); ?></a>
							<span class="hint"><?php echo esc_html( aifp_t( 'Déjà Pro ? Collez l’adresse de votre flux dans « Articles pour votre site ».', 'Already Pro? Paste your feed address under “Articles for your site”.' ) ); ?></span>
						<?php endif; ?>
					</div>
				</div>
				<div>
					<label class="l"><?php echo esc_html( aifp_t( 'Aperçu', 'Preview' ) ); ?></label>
					<div class="aifp-mock" id="aifp-mock" data-fr="<?php echo $fr ? '1' : ''; ?>"></div>
				</div>
			</form>
		</div>

		<div class="aifp-foot">
			<span><?php echo esc_html( aifp_t( 'Des probabilités, pas des certitudes. Pas un conseil de pari.', 'Probabilities, not certainty. Not betting advice.' ) ); ?></span>
			<a href="<?php echo esc_url( $site . 'support/?src=wp' ); ?>" target="_blank" rel="noopener"><?php echo esc_html( aifp_t( 'Besoin de plus ? Plusieurs sites, plus d’articles : contactez-nous', 'Need more? Several sites, more articles: contact us' ) ); ?></a>
		</div>
	</div>
	<?php
}

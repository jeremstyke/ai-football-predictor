/* AI Football Predictor block (no build step). */
( function ( wp ) {
	var el = wp.element.createElement, fr = window.AIFP_I18N && window.AIFP_I18N.fr;
	var T = function ( a, b ) { return fr ? a : b; };
	var C = wp.components, BE = wp.blockEditor, SSR = wp.serverSideRender;
	wp.blocks.registerBlockType( 'aifp/widget', {
		title: 'AI Football Predictor',
		description: T( 'Les probabilités des matchs de foot.', 'Football match probabilities.' ),
		icon: 'chart-bar',
		category: 'widgets',
		keywords: [ 'football', 'foot', 'probabilities', 'probabilités' ],
		edit: function ( p ) {
			var a = p.attributes, set = function ( k ) { return function ( v ) { var o = {}; o[ k ] = v; p.setAttributes( o ); }; };
			return el( 'div', BE.useBlockProps(),
				el( BE.InspectorControls, null,
					el( C.PanelBody, { title: T( 'Réglages', 'Settings' ) },
						el( C.SelectControl, { label: 'Type', value: a.type, onChange: set( 'type' ), options: [
							{ label: T( 'Prochains matchs', 'Next matches' ), value: 'matches' },
							{ label: T( 'En direct', 'Live' ), value: 'live' },
							{ label: T( 'Classement probable', 'Projected table' ), value: 'table' },
							{ label: T( 'Club', 'Club' ), value: 'team' },
							{ label: T( 'Articles', 'Articles' ), value: 'articles' } ] } ),
						el( C.TextControl, { label: T( 'Compétitions (codes, ex. F1,CL)', 'Competitions (codes, e.g. E0,CL)' ), value: a.competitions, onChange: set( 'competitions' ) } ),
						el( C.TextControl, { label: T( 'Club (facultatif)', 'Club (optional)' ), value: a.team, onChange: set( 'team' ) } ),
						el( C.TextControl, { label: T( 'Nombre de matchs', 'Number of matches' ), value: a.n, onChange: set( 'n' ) } ),
						el( C.SelectControl, { label: T( 'Langue', 'Language' ), value: a.lang, onChange: set( 'lang' ), options: [ { label: 'Français', value: 'fr' }, { label: 'English', value: 'en' } ] } ),
						el( C.SelectControl, { label: T( 'Thème', 'Theme' ), value: a.theme, onChange: set( 'theme' ), options: [ { label: T( 'Sombre', 'Dark' ), value: 'dark' }, { label: T( 'Clair', 'Light' ), value: 'light' } ] } )
					)
				),
				el( 'div', { style: { padding: '12px', border: '1px dashed #999', fontSize: '13px' } },
					'⚽ AI Football Predictor · ' + T( 'le widget s’affiche sur la page publiée.', 'the widget shows on the published page.' ),
					el( SSR, { block: 'aifp/widget', attributes: a } ) )
			);
		},
		save: function () { return null; }
	} );
} )( window.wp );
